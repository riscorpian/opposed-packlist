var pagestring=/#\/(blug|packlist|projects|about)$/i;var cpage=window.location.hash;if(cpage.match(pagestring))
cpage=RegExp.$1;else
cpage='packlist';function parseJQ(){$('#nav li.navsel').removeClass('navsel');switch(cpage){case'blug':$('#nav li').eq(0).addClass('navsel');break;case'packlist':$('#nav li').eq(1).addClass('navsel');$('#packlist ul').click(function(){finishTutorial($(this).children().eq(0).text(),$(this).children().eq(1).text());});break;case'projects':$('#nav li').eq(2).addClass('navsel');break;case'about':$('#nav li').eq(3).addClass('navsel');break;}}
function switchPage(){if(window.location.hash.match(pagestring))
thepage=RegExp.$1;else
thepage=cpage;if(thepage!=cpage){throbberToggle();$('#container').load(thepage+'.php',function(){throbberToggle();cpage=thepage;parseJQ();});}}
function finishTutorial(p,f){$('#overlay').fadeIn(300);$('#overlay span').text(f);$('#overlay input').val('/msg Rera xdcc send #'+p).click(function(){$(this).select();}).focus().select().blur(function(){$('#overlay').fadeOut(300);});}
function throbberToggle(){if($('#throbber').css('display')=='none'){$('#throbber').fadeIn(200);rotateThrobber();}else
$('#throbber').fadeOut(300);}
function rotateThrobber(){$('#throbber').rotate('0deg');$('#throbber').animate({rotate:'-360deg'},{duration:1000,easing:'linear',queue:false,complete:function(){if($('#throbber').css('display')!='none')
rotateThrobber();}});}
$(function(){$('#header div, #container, #color').hide();$('#header').height(40).width('.5%').css({'opacity':'0','top':'150px'});if(cpage!='packlist')
$('#container').load(cpage+'.php',function(){parseJQ();})
else
parseJQ();window.onhashchange=switchPage;$('#header').delay(300)
.animate({top:'0px',opacity:.67,height:'60px',width:'1%'},200,'easeOutCirc')
.animate({opacity:1,height:'100px',width:'1.05%'},200,'easeInCirc',function(){$('#header').css({'background':'-moz-linear-gradient(left, rgb(255, 255, 255), rgb(0, 0, 0)) no-repeat left, -moz-linear-gradient(right, rgb(255, 255, 255), rgb(0, 0, 0)) no-repeat right, rgb(0, 0, 0)','background-size':'1% 100%, 1% 100%'});}).animate({width:'102%'},200,function(){$('#header').css({'background':'rgb(0, 0, 0)','background-size':'100% 100%'});});$('#header div').delay(900).fadeIn(350);$('#color').delay(900).fadeIn(350);$('#color div').show().delay(900)
.animate({'width':'0'},900,'easeInQuart').hide();$('#container').delay(900).fadeIn(500);$(window).scroll(function(){var refh=Math.floor(($(window).scrollTop()/(document.body.scrollHeight-window.innerHeight)*100)/4);$('#plheaderfade').height(refh);$('#footerfade').height(25-refh);});});