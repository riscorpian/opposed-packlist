function finishTutorial(p,f){$('#overlay').fadeIn(300);$('#overlay span').text(f);$('#overlay input').val('/msg Rera xdcc send #'+p).click(function(){$(this).select();}).focus().select().blur(function(){$('#overlay').fadeOut(300);});}
$(function(){$('#header div, #container, #color').hide();$('#header').height(40).width('.5%').css({'opacity':'0','top':'150px'}).delay(300)
.animate({top:'0px',opacity:.67,height:'60px',width:'1%'},200,'easeOutCirc')
.animate({opacity:1,height:'100px',width:'1.05%'},200,'easeInCirc')
.animate({width:'100%'},200);$('#header div').delay(900).fadeIn(350);$('#color').delay(900).fadeIn(350);$('#color div').show().delay(900)
.animate({'width':'0'},900,'easeInQuart').hide();$('#container').delay(900).fadeIn(500);$('#packlist ul').click(function(){finishTutorial($(this).children().eq(0).text(),$(this).children().eq(1).text());})});